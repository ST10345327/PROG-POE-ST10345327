using System.Windows;

namespace RecipeAppWPF
{
    public partial class App : Application
    {
    }
}
