using System;

namespace RecipeApp
{
    // Ingredient class with additional properties for Part 2
    public class Ingredient
    {
        public string Name { get; set; }
        public int Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }

        public void EnterDetails()
        {
            Console.WriteLine("Enter ingredient name:");
            Name = Console.ReadLine();

            Console.WriteLine("Enter quantity:");
            while (!int.TryParse(Console.ReadLine(), out Quantity) || Quantity <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
            }

            Console.WriteLine("Enter unit of measurement:");
            Unit = Console.ReadLine();

            Console.WriteLine("Enter number of calories:");
            while (!int.TryParse(Console.ReadLine(), out Calories) || Calories <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
            }
        }
    }
}
