﻿using System;
using System.Linq;

namespace RecipeApplication;



// Class to represent an ingredient
class Ingredient
{
	public string Name { get; set; }      // Name of the ingredient
	public double Quantity { get; set; }  // Quantity of the ingredient
	public string Unit { get; set; }      // Unit of measurement for the ingredient
}

// Class to represent a step in the recipe
class RecipeStep
{
	public string Description { get; set; }  // Description of the step
}

// Class to represent a recipe
class Recipe
{
	public Ingredient[] Ingredients { get; set; }  // Array to store ingredients
	public RecipeStep[] Steps { get; set; }        // Array to store recipe steps

	// Method to display the recipe
	public void DisplayRecipe()
	{
		Console.WriteLine("Ingredients:");
		foreach (var ingredient in Ingredients)
		{
			Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
		}

		Console.WriteLine("\nSteps:");
		for (int i = 0; i < Steps.Length; i++)
		{
			Console.WriteLine($"{i + 1}. {Steps[i].Description}");
		}
	}

	// Method to scale the recipe by a factor
	public void ScaleRecipe(double factor)
	{
		foreach (var ingredient in Ingredients)
		{
			ingredient.Quantity *= factor;
		}
	}

	// Method to reset ingredient quantities to original values
	public void ResetQuantities()
	{
		// Logic to reset quantities to original values (to be implemented)
	}

	// Method to clear all data
	public void ClearData()
	{
		Ingredients = new Ingredient[0];
		Steps = new RecipeStep[0];
	}
}

class Program
{
	static void Main(string[] args)
	{
		// Create a new recipe
		Recipe recipe = new Recipe();

		// Get user input for the number of ingredients (with validation)
		int numIngredients;
		do
		{
			Console.Write("Enter the number of ingredients: ");
		} while (!int.TryParse(Console.ReadLine(), out numIngredients) || numIngredients <= 0);

		// Initialize ingredients array with user-specified length
		recipe.Ingredients = new Ingredient[numIngredients];

		// Get user input for each ingredient
		for (int i = 0; i < numIngredients; i++)
		{
			Console.WriteLine($"Enter details for ingredient {i + 1}:");
			Console.Write("Name: ");
			string name = Console.ReadLine();
			double quantity;
			do
			{
				Console.Write("Quantity: ");
				if (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
				{
					Console.WriteLine("Invalid input. Quantity must be a positive number.");
				}
			} while (quantity <= 0);
			Console.Write("Unit: ");
			string unit = Console.ReadLine();

			// Create new Ingredient object and add it to the array
			recipe.Ingredients[i] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
		}

		// Get user input for the number of steps (with validation)
		int numSteps;
		do
		{
			Console.Write("Enter the number of steps: ");
		} while (!int.TryParse(Console.ReadLine(), out numSteps) || numSteps <= 0);

		// Initialize steps array with user-specified length
		recipe.Steps = new RecipeStep[numSteps];

		// Get user input for each step
		for (int i = 0; i < numSteps; i++)
		{
			Console.WriteLine($"Enter details for step {i + 1}:");
			Console.Write("Description: ");
			string description = Console.ReadLine();

			// Create new RecipeStep object and add it to the array
			recipe.Steps[i] = new RecipeStep { Description = description };
		}

		// Display the recipe
		Console.WriteLine("\nRecipe:");
		recipe.DisplayRecipe();

		// Scale the recipe
		double scalingFactor;
		do
		{
			Console.Write("\nEnter scaling factor (0.5, 2, or 3): ");
			if (!double.TryParse(Console.ReadLine(), out scalingFactor) || (scalingFactor != 0.5 && scalingFactor != 2 && scalingFactor != 3))
			{
				Console.WriteLine("Invalid input. Scaling factor must be 0.5, 2, or 3.");
			}
		} while (scalingFactor != 0.5 && scalingFactor != 2 && scalingFactor != 3);
		recipe.ScaleRecipe(scalingFactor);
		Console.WriteLine("\nScaled Recipe:");
		recipe.DisplayRecipe();

		// Reset ingredient quantities (to be implemented)
		recipe.ResetQuantities();

		// Clear all data
		recipe.ClearData();
	}
}
